import dotenv from 'dotenv';
import OpenAI from 'openai';
import express from 'express';
import mongoose from 'mongoose';
import Image from './models/Images.js'; 
import cors from 'cors';

dotenv.config();

const api = process.env.OPENAI_API_KEY;
const openai = new OpenAI({apiKey: api});

const app = express();
const PORT = 3000;

app.use(cors({
    origin:'http://localhost:5173',
    methods: ['GET','POST','OPTIONS'],
}))

app.use(express.json());

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});



//Mongoose configuration
const mongoURI = "mongodb://localhost/pixifyDB";
mongoose.connect(mongoURI)
    .then(() => console.log("MongoDB connected successfully!"))
    .catch((err) => console.error("MongoDB connection error: ", err));


//Route to generate image based on user's prompt
app.post('/generate-image', async(req, res) => {
    console.log("Received prompt:", req.body.prompt);
    const {prompt} = req.body;
    try {
        const image = await openai.images.generate({prompt});
        const imageURL = image.data[0].url;
        res.status(200).json({imageURL, prompt});
    } catch(error) {
        console.error("Error generating image:", error);
        res.status(500).json({error: "Error generating image"});
    }
})



// Function to add image to database
const addImageToDatabase = async (imageURL, prompt, sessionID) => {
    const image = new Image({ imageURL, prompt, sessionID });
    try {
        const savedImage = await image.save();
        console.log("Image saved to the database:", savedImage);
        return savedImage; 
    } catch (error) {
        console.error("Error saving image to database:", error);
    }
}

// Route handler using the helper function
app.post("/save-image", async (req, res) => {
    console.log("Received request to save image:", req.body);

    const { imageURL, prompt, sessionID } = req.body;

    // Validate fields
    if (!imageURL || !prompt) {
        console.log("Missing imageURL or prompt");
        return res.status(400).json({ error: "Both 'imageURL' and 'prompt' are required." });
    }

    try {
        console.log("Calling addImageToDatabase...");
        const savedImage = await addImageToDatabase(imageURL, prompt, sessionID); 
        console.log("Image saved successfully:", savedImage);
        res.status(200).json({ message: "Image saved!" });
    } catch (error) {
        console.error("Error in try/catch:", error);
        res.status(500).json({ error: "Error saving image." });
    }
});

//Fetch images (only with the correct sessionID) for library. 
app.get("/fetch-images", async (req, res) => {
    const sessionID = req.query.sessionID;
    console.log("Recieved sessionID:", sessionID);

    try {
        if (!sessionID) {
            return res.status(400).json({error: "SessionID is required"});
        
        }

        //Find images in the database that match the currect sessionID
        const images = await Image.find({sessionID});
        if (images.length ==0) {
            return res.status(200).json({message: "No images yet for this session"});
        }

        res.status(200).json(images);
    } catch(error) {
            console.error("Error fetching images from database", error);
            res.status(500).json({error: "Error fetching images"});
        }
    
});



