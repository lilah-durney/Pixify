import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

import "./Library.css";

interface LibraryProps {
    sessionID: string;
}

interface Image {
    imageURL: string;
    prompt: string;
    sessionID: string;
}

const Library: React.FC<LibraryProps> = ({ sessionID }) => {
    const [images, setImages] = useState<Image[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    
    console.log("SessionID", sessionID);

    // useEffect(() => {
    //     const fetchImages = async () => {

    //         try {
    //             const response = await axios.get(`http://localhost:3000/fetch-images?sessionID=${sessionID}`);
    //             console.log("SessionID", sessionID);
    //             console.log(response);
    //             const fetchedImages = response.data;
    //             setImages(fetchedImages);
    //             setLoading(false);
    //         } catch (error) {
    //             console.error("Error fetching images", error);
    //             setError("Could not fetch images");
    //             setLoading(false);
    //         }
    //     };

    //     fetchImages();
    // }, [sessionID]);

    const fetchImages = async () => {
        if (sessionID) {

        try {
            console.log("Fetching images with sessionID:", sessionID);
            const response = await fetch(`http://localhost:3000/fetch-images`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ sessionID: sessionID }),
            });

            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            const fetchedImages = await response.json();
            setImages(fetchedImages);
            setLoading(false);
        } catch (error) {
            console.log(error);
            setError("Could not fetch images");
            setLoading(false);
        }
    };
    }

    useEffect(() => {
        fetchImages();
    }, [sessionID]);

    if (loading) {
        return <div className="loading-message">Loading library...</div>;
    }

    if (error) {
        return <div className="error-message">{error}</div>;
    }

    return (
        <div className="library-container">
            <h1 className="library-title">Library Page</h1>
            <div className="library-grid">
                {images.length === 0 ? (
                    <div className="no-images">
                        <p>No images have been added yet to the library</p>
                        <Link to="/create">
                            <button className="create-button">Create</button>
                        </Link>
                    </div>
                ) : (
                    images.map((image, index) => (
                        <div key={index} className="library-item">
                            <img src={image.imageURL} alt={`Generated for ${image.prompt}`} className="library-image" />
                            <p className="image-prompt">{image.prompt}</p>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default Library;
