import React, { useEffect, useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './pages/Home/Home.tsx';
import Create from './pages/Create/Create.tsx';
import Library from './pages/Library/Library.tsx';
import SideNavbar from './Components/SideNavBar/SideNavbar.tsx';

const App: React.FC = () => {
  const [sessionID, setSessionID] = useState<string>('');

  useEffect(() => {
    // Check if there's already a session ID in sessionStorage (to allow persistence across refreshes)
    const existingSessionID = sessionStorage.getItem('sessionID');

    if (!existingSessionID) {
      // Create a new sessionID if it doesn't already exist
      const newSessionID = Date.now().toString();
      sessionStorage.setItem('sessionID', newSessionID);
      setSessionID(newSessionID);
    } else {
      // Use the existing sessionID
      setSessionID(existingSessionID);
    }
    console.log("SessionID:", sessionID);
  }, [sessionID]); // Added sessionID as a dependency to ensure the useEffect runs correctly

  return (
    <div className="app-container">
      {/* Add the SideNavbar here */}
      <SideNavbar />

      <div className="main-content">
        {/* Define the routes and pass sessionID to necessary pages */}
        <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/create" element={<Create sessionID={sessionID} />} />
          <Route path="/library" element={<Library sessionID={sessionID} />} />
        </Routes>
      </div>
    </div>
  );
};

export default App;
